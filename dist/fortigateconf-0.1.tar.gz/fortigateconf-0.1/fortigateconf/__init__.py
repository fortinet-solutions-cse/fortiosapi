from .fortigateconf import FortiOSConf
