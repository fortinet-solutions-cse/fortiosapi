#!/usr/bin/env python

from os.path import join, dirname

from cloudify import ctx

ctx.download_resource(
    join('components', 'utils.py'),
    join(dirname(__file__), 'utils.py'))
import utils  # NOQA

REST_SERVICE_NAME = 'restservice'


ctx.logger.info('Stopping Cloudify REST Service...')
utils.systemd.stop(REST_SERVICE_NAME)
